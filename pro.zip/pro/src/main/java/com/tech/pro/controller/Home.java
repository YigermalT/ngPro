package com.tech.pro.controller;



import com.tech.pro.domain.ContactUs;
import com.tech.pro.domain.ServiceResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
public class Home {


    @GetMapping(value = "/")
    public String getHome(){
        return "pages/home";
    }

    @GetMapping(value = "/about")
    public String getHome(Model model){ return "pages/about"; }


    @GetMapping(value="/contactus")
    public String contact(Model model){ return "pages/contact";
    }

    @RequestMapping(value="/itconsulting", method = RequestMethod.GET)
    public String staffing(){ return "pages/serviceandproducts/itconsulting"; }

    @RequestMapping(value="/consulting", method = RequestMethod.GET)
    public String consulting(){ return "pages/serviceandproducts/itconsulting"; }

    @RequestMapping(value="/projects", method = RequestMethod.GET)
    public String projects(){ return "pages/serviceandproducts/projects"; }

    @RequestMapping(value="/training", method = RequestMethod.GET)
    public String training(){ return "pages/serviceandproducts/training"; }

    @RequestMapping(value="/courses", method = RequestMethod.GET)
    public String courString(){ return "pages/serviceandproducts/training/courses"; }

    @RequestMapping(value="/carrier", method = RequestMethod.GET)
    public String carrier(){
        return "pages/carrier/carrier";
    }


    @RequestMapping(value="/scJava", method = RequestMethod.GET)
    public String courseJava(){
        return "pages/serviceandproducts/training/single-courseJava";
    }

    @RequestMapping(value="/esa", method = RequestMethod.GET)
    public String esa(){
        return "pages/serviceandproducts/training/esa";
    }

    @PostMapping(value = "/savec")
    public ResponseEntity<Object> cSave(@RequestBody ContactUs contactUs) {
        ServiceResponse<ContactUs> response = new ServiceResponse<ContactUs>(1, "success", contactUs);
        return new ResponseEntity<Object>(new ServiceResponse<>(1, "success", contactUs), HttpStatus.OK);
    }


}
