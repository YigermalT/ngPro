package com.tech.pro.domain;





//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import lombok.ToString;

//@Data
//@ToString
public class ServiceResponse<T> {
	private int sendstatus;
	private String status;
	private T data;

	public ServiceResponse(int sendstatus, String success, T book) {
		this.setSendstatus(sendstatus);
		this.status=success;
		this.data=book;
	}
	public ServiceResponse(String success, T book) {
		this.status=success;
		this.data=book;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public int getSendstatus() {
		return sendstatus;
	}

	public void setSendstatus(int sendstatus) {
		this.sendstatus = sendstatus;
	}
	
	
}
